/*
 * FunCaptcha dataset tracker - collector (isolated world).
 *
 * Runs in the same isolated world as the YesCaptcha solver (captcha_manager.js)
 * and in every frame. It captures solved FunCaptcha challenges purely by
 * observation and uploads them to the collector server:
 *
 *   - game_variant : received from fc_variant_hook.js (MAIN world) via postMessage
 *   - image + question + answer index : read from the solver's createTask call
 *   - verified solved : a `victory` flushes the buffer; a `fail` discards it
 *
 * How capture works: the solver does NOT use window.fetch for its API calls -
 * it sends them to the background worker via chrome.runtime.sendMessage
 * ({action:"post", url:".../createTask", data:{task:{image,question,...}}}) and
 * the response (with `solution`) comes back in the callback. So we wrap
 * chrome.runtime.sendMessage to observe that traffic.
 *
 * HARD REQUIREMENT: the tracker must never break solving. The sendMessage
 * wrapper ALWAYS delegates to the original and returns its result; the original
 * callback is always invoked with the original arguments. All tracker logic is
 * wrapped in try/catch. If anything here fails, solving is unaffected.
 */
(function () {
    "use strict";

    var TAG = "[fc-tracker]";
    var DEBUG = false; // set false to silence diagnostics
    var origFetch = window.fetch ? window.fetch.bind(window) : null;

    function dbg() {
        if (!DEBUG) return;
        try {
            var a = Array.prototype.slice.call(arguments);
            a.unshift(TAG);
            console.log.apply(console, a);
        } catch (e) {}
    }

    var cfg = { enabled: true, serverUrl: "https://training.farmsync.cloud/collect" };
    var currentVariant = null;   // latest game_variant seen for this frame
    var buffer = [];             // solved waves pending verification

    // ---- config ----
    function loadConfig() {
        try {
            if (!window.chrome || !chrome.storage || !chrome.storage.local) return;
            chrome.storage.local.get(["config"], function (r) {
                try {
                    var c = (r && r.config && r.config.funcaptchaTrackerConfig) || null;
                    if (c) {
                        if (typeof c.enabled === "boolean") cfg.enabled = c.enabled;
                        if (c.serverUrl) cfg.serverUrl = c.serverUrl;
                    }
                    dbg("config loaded: enabled =", cfg.enabled, "serverUrl =", cfg.serverUrl, c ? "" : "(no funcaptchaTrackerConfig in storage!)");
                } catch (e) {}
            });
        } catch (e) {}
    }
    // Persist the latest variant to chrome.storage so it reaches the solving
    // frame even if it was detected in a different Arkose frame.
    function shareVariant(v) {
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.set({ fcTrackerLastVariant: { variant: v, ts: Date.now() } });
            }
        } catch (e) {}
    }

    try {
        loadConfig();
        // seed currentVariant from any value another frame already stored
        try {
            if (window.chrome && chrome.storage && chrome.storage.local) {
                chrome.storage.local.get(["fcTrackerLastVariant"], function (r) {
                    try {
                        var lv = r && r.fcTrackerLastVariant;
                        if (lv && lv.variant && !currentVariant) {
                            currentVariant = lv.variant;
                            dbg("variant seeded from storage:", currentVariant);
                        }
                    } catch (e) {}
                });
            }
        } catch (e) {}
        if (window.chrome && chrome.storage && chrome.storage.onChanged) {
            chrome.storage.onChanged.addListener(function (changes, area) {
                if (area !== "local") return;
                if (changes.config) loadConfig();
                if (changes.fcTrackerLastVariant) {
                    var nv = changes.fcTrackerLastVariant.newValue;
                    if (nv && nv.variant) {
                        currentVariant = nv.variant;
                        dbg("variant from another frame:", currentVariant);
                    }
                }
            });
        }
    } catch (e) {}

    // ---- variant from MAIN world (same frame) ----
    try {
        window.addEventListener("message", function (ev) {
            try {
                var d = ev && ev.data;
                if (d && d.source === "fc-tracker" && d.type === "variant" && d.variant) {
                    currentVariant = d.variant;
                    dbg("variant captured:", currentVariant);
                    shareVariant(d.variant); // broadcast to other frames
                }
            } catch (e) {}
        });
    } catch (e) {}

    // ---- helpers ----
    function argmax(arr) {
        var best = -Infinity, bi = 0;
        for (var i = 0; i < arr.length; i++) {
            if (typeof arr[i] === "number" && arr[i] > best) { best = arr[i]; bi = i; }
        }
        return bi;
    }

    function solutionIndex(solution) {
        try {
            if (!solution) return null;
            if (Array.isArray(solution.objects) && solution.objects.length) {
                var v = solution.objects[0];
                if (typeof v === "number") return v;
            }
            if (Array.isArray(solution.confidences) && solution.confidences.length) {
                return argmax(solution.confidences);
            }
            return null;
        } catch (e) {
            return null;
        }
    }

    // Combine a createTask request task + response into a buffered record.
    function recordSolve(task, resp) {
        try {
            if (!task) { dbg("recordSolve: no task in request"); return; }
            var type = task.type || "";
            if (type.toLowerCase().indexOf("funcaptcha") === -1) { dbg("recordSolve: not FunCaptcha (type =", type, ")"); return; }
            var image = task.image;
            if (!image) { dbg("recordSolve: no image in task"); return; }
            var idx = solutionIndex(resp && resp.solution);
            if (idx === null || idx === undefined) { dbg("recordSolve: no solution index in response", resp && resp.solution); return; }
            if (idx < 0 || idx > 20) { dbg("recordSolve: index out of 0-20 range:", idx); return; }
            buffer.push({
                variant: currentVariant,
                index: idx,
                image: image,
                question: task.question || ""
            });
            dbg("buffered solve: variant =", currentVariant, "index =", idx, "(buffer size", buffer.length + ")",
                currentVariant ? "" : "<-- variant is null, will be dropped on upload");
        } catch (e) { dbg("recordSolve error", e); }
    }

    function upload(rec) {
        try {
            if (!rec || !rec.variant) { dbg("upload: dropping record with no variant", rec); return; }
            dbg("uploading", rec.variant + "/" + rec.index, "via background ->", cfg.serverUrl);
            // Route through the background service worker (existing "post" action)
            // so the request survives the captcha iframe being torn down on victory.
            // The bare fetch from this frame would be aborted mid-body (EOF).
            if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage(
                    { action: "post", url: cfg.serverUrl, data: rec, delay: 0, tries: 2 },
                    function (resp) {
                        try {
                            if (chrome.runtime && chrome.runtime.lastError) {
                                dbg("upload error (background):", chrome.runtime.lastError.message);
                                return;
                            }
                            dbg("upload response:", resp, rec.variant + "/" + rec.index);
                        } catch (e) {}
                    }
                );
                return;
            }
            // Fallback: keepalive fetch (lets the request outlive the frame).
            if (origFetch) {
                origFetch(cfg.serverUrl, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(rec),
                    keepalive: true
                }).then(function (res) {
                    dbg("upload response (fetch):", res && res.status, rec.variant + "/" + rec.index);
                }).catch(function (err) {
                    dbg("upload FAILED:", err && err.message, "->", cfg.serverUrl);
                });
            }
        } catch (e) { dbg("upload error", e); }
    }

    function flushBuffer() {
        try {
            dbg("VICTORY detected -> flushing", buffer.length, "record(s); enabled =", cfg.enabled);
            if (!cfg.enabled) { dbg("tracker disabled -> discarding buffer (set funcaptchaTrackerConfig.enabled = true)"); buffer = []; return; }
            var pending = buffer;
            buffer = [];
            for (var i = 0; i < pending.length; i++) upload(pending[i]);
        } catch (e) {
            buffer = [];
        }
    }

    function discardBuffer() {
        buffer = [];
    }

    // ---- chrome.runtime.sendMessage override (delegates, never blocks) ----
    try {
        if (window.chrome && chrome.runtime && typeof chrome.runtime.sendMessage === "function") {
            var origSend = chrome.runtime.sendMessage.bind(chrome.runtime);
            var wrapper;
            wrapper = function () {
                try {
                    var args = Array.prototype.slice.call(arguments);
                    var msg = args.length && args[0] && typeof args[0] === "object" ? args[0] : null;
                    var cbIdx = -1;
                    for (var i = args.length - 1; i >= 0; i--) {
                        if (typeof args[i] === "function") { cbIdx = i; break; }
                    }
                    if (
                        msg && msg.action === "post" &&
                        typeof msg.url === "string" && msg.url.indexOf("createTask") !== -1 &&
                        cbIdx !== -1
                    ) {
                        var task = msg.data && msg.data.task;
                        dbg("intercepted createTask; task type =", task && task.type, "has image =", !!(task && task.image));
                        var origCb = args[cbIdx];
                        args[cbIdx] = function (resp) {
                            try { recordSolve(task, resp); } catch (e) {}
                            return origCb.apply(this, arguments);
                        };
                        return origSend.apply(chrome.runtime, args);
                    }
                } catch (e) {}
                return origSend.apply(chrome.runtime, arguments);
            };
            chrome.runtime.sendMessage = wrapper;
            dbg("sendMessage override installed =", chrome.runtime.sendMessage === wrapper);
        }
    } catch (e) {
        dbg("could not override sendMessage (solver still works):", e);
    }

    // ---- victory / fail detection (mirrors the solver's DOM signals) ----
    function classifyNode(node) {
        try {
            if (!node || node.nodeType !== 1) return null;
            var id = node.id || "";
            var cls = (typeof node.className === "string" ? node.className : "") || "";
            if (id === "victory" || /victory/i.test(cls)) return "victory";
            if (id === "wrong" || /wrong/i.test(id) || /match-game-fail|(^|\s)fail(\s|$)|alert box/i.test(cls)) return "fail";
            if (node.querySelector) {
                if (node.querySelector('[id="victory"], [class*="victory"]')) return "victory";
                if (node.querySelector('[id^="wrong"], [class*="match-game-fail"]')) return "fail";
            }
            return null;
        } catch (e) {
            return null;
        }
    }

    try {
        var observer = new MutationObserver(function (mutations) {
            try {
                for (var i = 0; i < mutations.length; i++) {
                    var added = mutations[i].addedNodes;
                    if (!added) continue;
                    for (var j = 0; j < added.length; j++) {
                        var verdict = classifyNode(added[j]);
                        if (verdict === "victory") { flushBuffer(); return; }
                        if (verdict === "fail") { discardBuffer(); return; }
                    }
                }
            } catch (e) {}
        });
        var startObserving = function () {
            try {
                if (document.body) {
                    observer.observe(document.body, { childList: true, subtree: true });
                } else {
                    document.addEventListener("DOMContentLoaded", startObserving, { once: true });
                }
            } catch (e) {}
        };
        startObserving();
    } catch (e) {}

    try { dbg("installed in frame:", location.href.slice(0, 80)); } catch (e) {}
})();
