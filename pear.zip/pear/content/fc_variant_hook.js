/*
 * FunCaptcha dataset tracker - variant hook (MAIN world).
 *
 * Runs in the page's JavaScript world inside the Arkose frames. Its ONLY job is
 * to read Arkose's `game_variant` (the real dataset folder name, e.g.
 * "dance_floor", "hopscotchv2", "numericalmatch") out of the game-data response
 * and forward it to the extension's isolated-world tracker via postMessage.
 *
 * Hard requirement: this must NEVER interfere with the page or the solver.
 * Every hook wraps the original call in try/catch and always returns the
 * original result untouched.
 */
(function () {
    "use strict";

    var TAG = "[fc-tracker:variant]";
    var DEBUG = false;

    function dbg() {
        if (!DEBUG) return;
        try {
            var a = Array.prototype.slice.call(arguments);
            a.unshift(TAG);
            console.log.apply(console, a);
        } catch (e) {}
    }

    // Recursively search a parsed object for Arkose's variant signal. Roblox
    // exposes it as `instruction_string` (e.g. "hopscotch_highsec"); some
    // deployments use `game_variant`. Returns the raw signal string.
    function deepFindRaw(obj, depth) {
        try {
            if (!obj || typeof obj !== "object" || depth > 6) return null;
            if (typeof obj.game_variant === "string" && obj.game_variant) return obj.game_variant;
            if (typeof obj.instruction_string === "string" && obj.instruction_string) return obj.instruction_string;
            for (var k in obj) {
                if (!Object.prototype.hasOwnProperty.call(obj, k)) continue;
                var v = obj[k];
                if (v && typeof v === "object") {
                    var found = deepFindRaw(v, (depth || 0) + 1);
                    if (found) return found;
                }
            }
            return null;
        } catch (e) {
            return null;
        }
    }

    // Use the raw Arkose signal (instruction_string / game_variant) as-is for the
    // folder name, only stripping characters the server won't accept. Keeping it
    // raw preserves differences like "hopscotch_highsec" vs "hopscotch_lowsec".
    function normalizeVariant(raw) {
        if (!raw) return null;
        var s = String(raw).replace(/[^A-Za-z0-9_-]/g, "");
        return s || null;
    }

    var lastPublished = null;
    function publish(raw) {
        try {
            var folder = normalizeVariant(raw);
            if (!folder) return;
            if (folder === lastPublished) return; // avoid spamming identical values
            lastPublished = folder;
            dbg("variant signal:", raw, "-> folder:", folder);
            window.postMessage(
                { source: "fc-tracker", type: "variant", variant: folder },
                "*"
            );
        } catch (e) {}
    }

    // Inspect an already-parsed object (e.g. XHR responseType "json").
    function inspectObject(obj, url) {
        try {
            var v = deepFindRaw(obj, 0);
            if (v) { publish(v); return true; }
            if (url && /gfct|\/fc\/gc|game/i.test(url)) {
                dbg("game-ish response but no variant signal. url:", String(url).slice(0, 80), "top keys:", obj && typeof obj === "object" ? Object.keys(obj).slice(0, 20) : obj);
            }
            return false;
        } catch (e) {
            return false;
        }
    }

    // Inspect a response body string.
    function inspectText(text, url) {
        try {
            if (!text || typeof text !== "string") return false;
            var looksRelevant = text.indexOf("game_variant") !== -1 || text.indexOf("instruction_string") !== -1 || text.indexOf("game_data") !== -1;
            if (!looksRelevant && !(url && /gfct|\/fc\/gc/i.test(url))) return false;
            var data = JSON.parse(text);
            return inspectObject(data, url);
        } catch (e) {
            return false;
        }
    }

    // --- JSON.parse hook (most reliable) ---
    // Arkose JSON-parses its game config in the game frame, even when the raw
    // network response was encrypted. We inspect any parsed string that mentions
    // game_variant. Cheap: a string indexOf gate before any deep scan.
    try {
        var origParse = JSON.parse;
        JSON.parse = function (text) {
            var result = origParse.apply(this, arguments);
            try {
                if (typeof text === "string" &&
                    (text.indexOf("game_variant") !== -1 || text.indexOf("instruction_string") !== -1)) {
                    var v = deepFindRaw(result, 0);
                    if (v) publish(v);
                }
            } catch (e) {}
            return result;
        };
        dbg("JSON.parse hook installed");
    } catch (e) {}

    // --- fetch hook ---
    try {
        var origFetch = window.fetch;
        if (typeof origFetch === "function") {
            window.fetch = function () {
                var p = origFetch.apply(this, arguments);
                try {
                    var reqUrl = arguments[0] && (typeof arguments[0] === "string" ? arguments[0] : arguments[0].url);
                    p.then(function (res) {
                        try {
                            res.clone().text().then(function (t) { inspectText(t, reqUrl || (res && res.url)); }, function () {});
                        } catch (e) {}
                        return res;
                    }).catch(function () {});
                } catch (e) {}
                return p;
            };
        }
    } catch (e) {}

    // --- XHR hook ---
    try {
        var XHR = window.XMLHttpRequest;
        if (XHR && XHR.prototype) {
            var origSend = XHR.prototype.send;
            XHR.prototype.send = function () {
                try {
                    this.addEventListener("load", function () {
                        try {
                            var url = this.responseURL || "";
                            var rt = this.responseType;
                            if (rt === "json") {
                                inspectObject(this.response, url);
                            } else if (rt === "" || rt === "text") {
                                inspectText(this.responseText, url);
                            } else if (rt === "document" || rt === "arraybuffer" || rt === "blob") {
                                // not text/json; only flag if it's clearly the game endpoint
                                if (/gfct|\/fc\/gc/i.test(url)) dbg("game endpoint with non-text responseType:", rt, url.slice(0, 80));
                            }
                        } catch (e) {}
                    });
                } catch (e) {}
                return origSend.apply(this, arguments);
            };
        }
    } catch (e) {}

    dbg("installed");
})();
