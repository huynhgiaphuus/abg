/* FarmSync Captcha — popup controller
 * Reads/writes the same chrome.storage.local keys the content scripts read,
 * so the existing solver/background bundles keep working unchanged.
 *
 * Storage schema (must match popup.bundle.js defaults):
 *   api_key     : string   ""
 *   appId       : string   ""
 *   power_on    : boolean  true
 *   funcaptcha  : { delayClick, loop, loopCount, isActive, maxImageCaptcha }
 */
(function () {
  "use strict";

  const storage = (typeof browser !== "undefined" && browser.storage) ? browser.storage.local
                : (typeof chrome  !== "undefined" && chrome.storage)  ? chrome.storage.local
                : null;
  const runtime = (typeof browser !== "undefined" && browser.runtime) ? browser.runtime
                : (typeof chrome  !== "undefined" && chrome.runtime)  ? chrome.runtime
                : null;

  const FUNCAPTCHA_DEFAULTS = {
    delayClick: 100,
    loop: true,
    loopCount: 1,
    isActive: true,
    maxImageCaptcha: 25,
  };

  const DEFAULT_PROXY = "http://localhost:8787";
  const BALANCE_PATH  = "/v2/getBalance";

  /* ---------------- DOM refs ---------------- */
  const $ = (id) => document.getElementById(id);
  const els = {
    version:   $("fs-version"),
    power:     $("fs-power-toggle"),
    apiKey:    $("fs-api-key"),
    apiSave:   $("fs-api-save"),
    apiHint:   $("fs-api-hint"),
    balance:   $("fs-balance"),
    quantity:  $("fs-quantity"),
    plan:      $("fs-plan"),
    fcChip:    $("fs-fc-chip"),
    fcActive:  $("fs-fc-active"),
    fcLoop:    $("fs-fc-loop"),
    fcCount:   $("fs-fc-loop-count"),
    fcDelay:   $("fs-fc-delay-click"),
    fcMax:     $("fs-fc-max-image"),
    toast:     $("fs-toast"),
  };

  let proxyUrl = DEFAULT_PROXY;

  /* ---------------- Helpers ---------------- */
  function storageGet(keys) {
    return new Promise((resolve) => {
      if (!storage) return resolve({});
      try { storage.get(keys, (v) => resolve(v || {})); }
      catch (_) { resolve({}); }
    });
  }
  function storageSet(obj) {
    return new Promise((resolve) => {
      if (!storage) return resolve();
      try { storage.set(obj, () => resolve()); }
      catch (_) { resolve(); }
    });
  }

  function toast(msg, kind = "ok", ms = 1800) {
    if (!els.toast) return;
    els.toast.textContent = msg;
    els.toast.classList.remove("fs-toast-err", "fs-toast-ok");
    if (kind === "err") els.toast.classList.add("fs-toast-err");
    else els.toast.classList.add("fs-toast-ok");
    els.toast.classList.add("fs-toast-show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => els.toast.classList.remove("fs-toast-show"), ms);
  }

  function setHint(msg, kind) {
    if (!els.apiHint) return;
    els.apiHint.textContent = msg || "";
    els.apiHint.classList.remove("fs-hint-err", "fs-hint-ok");
    if (kind === "err") els.apiHint.classList.add("fs-hint-err");
    else if (kind === "ok") els.apiHint.classList.add("fs-hint-ok");
  }

  function fmtBalance(n) {
    const v = parseFloat(n);
    if (!isFinite(v)) return "—";
    return "$" + v.toFixed(5);
  }
  function fmtInt(n) {
    const v = parseInt(n, 10);
    if (!isFinite(v)) return "—";
    return v.toLocaleString();
  }

  /* ---------------- Config (proxy_url from configs.json) ---------------- */
  async function loadExtensionConfig() {
    try {
      if (!runtime || !runtime.getURL) return;
      const url = runtime.getURL("configs.json");
      if (!url) return;
      const res = await fetch(url);
      if (!res.ok) return;
      const j = await res.json();
      if (j && typeof j.proxy_url === "string" && j.proxy_url) {
        proxyUrl = j.proxy_url.replace(/\/+$/, "");
      }
    } catch (_) { /* keep default */ }
  }

  function loadManifestVersion() {
    try {
      const m = runtime && runtime.getManifest && runtime.getManifest();
      if (!m || !els.version) return;
      const v = m.version_name || m.version;
      if (v) els.version.textContent = "v" + v;
    } catch (_) { /* ignore */ }
  }

  /* ---------------- Balance ---------------- */
  async function fetchBalance(clientKey) {
    if (!clientKey) return { error: true, message: "API Key is empty" };
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    const init = {
      method: "POST",
      headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" },
      body: JSON.stringify({ clientKey }),
      signal: ctrl.signal,
    };
    try {
      const res = await fetch(proxyUrl + BALANCE_PATH, init);
      if (!res.ok) return { error: true, message: "Proxy HTTP " + res.status };
      return await res.json();
    } catch (e) {
      const msg = (e && e.name === "AbortError")
        ? "Proxy timed out at " + proxyUrl
        : "Proxy unreachable at " + proxyUrl;
      return { error: true, message: msg };
    } finally {
      clearTimeout(timer);
    }
  }

  async function refreshBalance(clientKey) {
    if (!clientKey) {
      els.balance.textContent = "—";
      els.quantity.textContent = "—";
      els.plan.textContent = "—";
      setHint("Enter your FarmSync client key to fetch balance.");
      return;
    }
    els.balance.textContent = "…";
    els.quantity.textContent = "…";
    els.plan.textContent = "…";
    const r = await fetchBalance(clientKey);
    if (r && r.error) {
      els.balance.textContent = "—";
      els.quantity.textContent = "—";
      els.plan.textContent = "—";
      setHint(r.message || "Failed to fetch balance", "err");
      return;
    }
    if (r && r.errorId === 0) {
      els.balance.textContent = fmtBalance(r.balance ?? 0);
      els.quantity.textContent = fmtInt(r.quantity ?? 0);
      els.plan.textContent = r.package_name || "—";
      setHint("Key verified", "ok");
    } else {
      els.balance.textContent = "—";
      els.quantity.textContent = "—";
      els.plan.textContent = "—";
      setHint((r && (r.errorDescription || r.message)) || "Invalid API key", "err");
    }
  }

  /* ---------------- State wiring ---------------- */
  function setPowerUI(on) {
    els.power.checked = !!on;
    document.body.classList.toggle("fs-off", !on);
  }

  function setFunCaptchaUI(cfg) {
    const c = Object.assign({}, FUNCAPTCHA_DEFAULTS, cfg || {});
    els.fcActive.checked = !!c.isActive;
    els.fcLoop.checked   = !!c.loop;
    els.fcCount.value    = c.loopCount ?? 1;
    els.fcDelay.value    = c.delayClick ?? 100;
    els.fcMax.value      = c.maxImageCaptcha ?? 25;
    updateFcChip();
  }

  function readFunCaptchaUI() {
    const cfg = {
      isActive:        !!els.fcActive.checked,
      loop:            !!els.fcLoop.checked,
      loopCount:       clampInt(els.fcCount.value, 1, 50, 1),
      delayClick:      clampInt(els.fcDelay.value, 0, 5000, 100),
      maxImageCaptcha: clampInt(els.fcMax.value, 1, 100, 25),
    };
    // Reflect clamped values back to inputs so the UI matches what's saved.
    els.fcCount.value = cfg.loopCount;
    els.fcDelay.value = cfg.delayClick;
    els.fcMax.value   = cfg.maxImageCaptcha;
    return cfg;
  }

  function clampInt(v, min, max, fallback) {
    const n = parseInt(v, 10);
    if (!isFinite(n)) return fallback;
    return Math.max(min, Math.min(max, n));
  }

  function updateFcChip() {
    const on = els.fcActive.checked;
    els.fcChip.textContent = on ? "Active" : "Disabled";
    els.fcChip.classList.toggle("fs-chip-off", !on);
  }

  /* ---------------- Persistence ---------------- */
  async function persistFunCaptcha() {
    updateFcChip(); // update UI synchronously; storage write is fire-and-forget
    const cfg = readFunCaptchaUI();
    await storageSet({ funcaptcha: cfg });
  }

  async function persistPower(on) {
    document.body.classList.toggle("fs-off", !on); // sync UI first
    await storageSet({ power_on: !!on });
  }

  async function saveApiKey() {
    const key = (els.apiKey.value || "").trim();
    els.apiSave.disabled = true;
    try {
      await storageSet({ api_key: key });
      toast("Client key saved", "ok");
      await refreshBalance(key);
    } finally {
      els.apiSave.disabled = false;
    }
  }

  /* ---------------- Init ---------------- */
  async function init() {
    loadManifestVersion();
    await loadExtensionConfig();

    const state = await storageGet(["api_key", "power_on", "funcaptcha"]);
    const apiKey = state.api_key || "";
    const powerOn = typeof state.power_on === "boolean" ? state.power_on : true;

    els.apiKey.value = apiKey;
    setPowerUI(powerOn);
    setFunCaptchaUI(state.funcaptcha);

    if (apiKey) refreshBalance(apiKey);
    else setHint("Enter your FarmSync client key to fetch balance.");

    /* listeners */
    els.apiSave.addEventListener("click", saveApiKey);
    els.apiKey.addEventListener("keydown", (e) => { if (e.key === "Enter") saveApiKey(); });

    els.power.addEventListener("change", () => persistPower(els.power.checked));

    [els.fcActive, els.fcLoop].forEach((el) =>
      el.addEventListener("change", persistFunCaptcha));
    [els.fcCount, els.fcDelay, els.fcMax].forEach((el) =>
      el.addEventListener("change", persistFunCaptcha));

    /* react to external storage changes (e.g. background updates) */
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== "local") return;
        if (changes.power_on)   setPowerUI(!!changes.power_on.newValue);
        if (changes.funcaptcha) setFunCaptchaUI(changes.funcaptcha.newValue);
        if (changes.api_key && document.activeElement !== els.apiKey) {
          els.apiKey.value = changes.api_key.newValue || "";
        }
      });
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
